This package contains the Example code for the 
"Validate XML Documents using Schemas and DTDs" article.
 
http://www.edankert.com/validate.html

It consists of:

The ./contacts.xml input XML file, ./contacts.xsd the XML Schema document, 
./contacts.dtd the DTD document and the source-code for the fragments above, 
located in the ./src directory.

The archive also contains a number XML Hammer validation projects included 
in the ./xmlhammer-projects directory.

To be able to execute these XML Hammer projects, you will need to have the 
XML Hammer application installed.

This can be downloaded from:
http://www.xmlhammer.org/
